﻿/**
* 11/04/2018
* CSC 253
* Gabriela Canjura
* person class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonClassLibrary
{
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string Telephone { get; set; }

        public Person (string firstName, string lastName, string address, string telephone)
        {
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Telephone = telephone;
        }
    }
}
