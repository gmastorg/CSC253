﻿/**
* 11/04/2018
* CSC 253
* Gabriela Canjura
* customer class inherits from person class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonClassLibrary
{
    public class Customer : Person
    {
        public int CustNum { get; set; }
        public bool MailingList { get; set; }

        public Customer(string firstName, string lastName, string address, string telephone, int custnum, bool mailinglist)
            :base(firstName, lastName, address, telephone)
        {
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Telephone = telephone;
            CustNum = custnum;
            MailingList = mailinglist;
        }

        public string getYesorNo()
        {
            if (MailingList == true)
            {
                return "Yes";
            }
            else
            {
                return "No";
            }
        }

        public override string ToString()
        {//override toString method

            return "Name: " + FirstName + " " + LastName + "\nAddress: " + Address +
                "\nTelephone: " + Telephone + "\nCustomer Number: " + CustNum + "\nMailing List: "
                + getYesorNo();
        }
    }
}
