﻿/**
* 11/04/2018
* CSC 253
* Gabriela Canjura
* creates customer objects from user input and displays it from listbox in messagebox
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonClassLibrary;

namespace M4HW4_Canjura
{
    public partial class Form1 : Form
    {
        List<Customer> customersList = new List<Customer>();

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {//closes form

            this.Close();
        }

        public void addButton_Click(object sender, EventArgs e)
        {
            // verifies that boxes are not null or unchecked
            if (firstNameTextBox.Text == "" || lastNameTextBox.Text == "" || streetAddressTextBox.Text == "" ||
               cityTextBox.Text == "" || zipMaskedTextBox.Text == "" || phoneMaskedTextBox.Text == "" ||
               custNumMaskedTextBox.Text == "" || stateComboBox.Text == "" ||
               (yesRadioButton.Checked == false && noRadioButton.Checked == false))
            {
                MessageBox.Show("Please Enter All Data Requested.");
            }
            else
            {
                //obtains text from user and assigns it to variables
                string firstName = firstNameTextBox.Text;
                string lastName = lastNameTextBox.Text;
                string address = streetAddressTextBox.Text + ". " + cityTextBox.Text + ", " + stateComboBox.Text +
                    " " + zipMaskedTextBox.Text;
                string phone = phoneMaskedTextBox.Text;
                int custnum = int.Parse(custNumMaskedTextBox.Text);
                bool mailinglist;
                if (yesRadioButton.Checked)
                {
                    mailinglist = true;
                }
                else
                {
                    mailinglist = false;
                }

                //calls method to clear data
                clearInfo();

                //creates customer object
                Customer customer = new Customer(firstName, lastName, address, phone, custnum, mailinglist);

                //adds customer objects to list
                customersList.Add(customer);

                //adds names to listbox
                displayListBox.Items.Add(lastName + ", " + firstName);
            }
        }

        public void clearInfo()
        {//clears data

            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            streetAddressTextBox.Text = "";
            cityTextBox.Text = "";
            stateComboBox.Text = "";
            zipMaskedTextBox.Text = "";
            phoneMaskedTextBox.Text = "";
            custNumMaskedTextBox.Text = "";          
        }

        private void displayListBox_SelectedIndexChanged(object sender, EventArgs e)
        {//displays data from objects in message box

            if (displayListBox.SelectedIndex != -1)
            {
                Customer selectedCustomer = customersList[displayListBox.SelectedIndex];
                MessageBox.Show(selectedCustomer.ToString());
            }
        }
    }
}
