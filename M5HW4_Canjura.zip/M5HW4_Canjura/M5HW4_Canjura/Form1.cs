﻿/**
* 11/22/2018
* CSC 253
* Gabriela Canjura
* sorts data by city name, ascending and descending population, adds, removes rows 
* and saves gets total pop, avg pop, highest and lowest pop
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M5HW4_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }

        private void ascendingButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPop(this.populationDBDataSet.City);
        }

        private void DescendingButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByDescPop(this.populationDBDataSet.City);
        }

        private void NameButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByCity(this.populationDBDataSet.City);
        }

        private void AvgButton_Click(object sender, EventArgs e)
        {
            //declare a variable to hold the average population
            decimal averagePop;

            //get average
            averagePop = (decimal)this.cityTableAdapter.AveragePop();

            //display avg
            avgTextBox.Text = averagePop.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //exit
            this.Close();
        }

        private void totButton_Click(object sender, EventArgs e)
        {
            //declare a variable to hold the total population
            int totalPop;

            //get total
            totalPop = (int)this.cityTableAdapter.TotalPop();

            //displaytotal
            totTextBox.Text = totalPop.ToString();
        }

        private void highestButton_Click(object sender, EventArgs e)
        {
            //declare a variable to hold the hignest population
            int highestPop;

            //get highest pop
            highestPop = (int)this.cityTableAdapter.HighestPop();

            //display highest Pop
            highestTextBox.Text = highestPop.ToString();
        }

        private void lowestButton_Click(object sender, EventArgs e)
        {
            //declare a variable to hold the lowest population
            int lowestPop;

            //get lowest pop
            lowestPop = (int)this.cityTableAdapter.LowestPop();

            //display lowest Pop
            lowestTextBox.Text = lowestPop.ToString();
        }
    }
}
