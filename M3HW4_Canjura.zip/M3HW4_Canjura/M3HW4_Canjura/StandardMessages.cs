﻿/**
* 10/16/2018
* CSC 253
* Gabriela Canjura
* Class that holds output to user
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW4_Canjura
{
    public class StandardMessages
    {
        public static void menu()
        {
            Console.WriteLine("1. Convert to Morse Code");
            Console.WriteLine("2. Exit");
            Console.WriteLine("Enter choice: ");
        }

        public static void invalidInput()
        {
            Console.WriteLine("Invalid choice.");
            Console.WriteLine("Enter your menu choice: ");
        }

        public static void getPhrase()
        {
            Console.WriteLine("Enter the word or phrase you want to convert to Morse Code.");
        }
    }
}
