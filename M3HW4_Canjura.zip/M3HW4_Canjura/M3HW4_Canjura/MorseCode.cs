﻿/**
* 10/16/2018
* CSC 253
* Gabriela Canjura
* Class creates dictionary and method that converts text to morse code
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M3HW4_Canjura
{
    public class MorseCode
    {
        public static Dictionary<string, string> createDictionary()
        {

            Dictionary<string, string> Morse = new Dictionary<string, string>();

            Morse = File.ReadLines("morseCode.csv").Select(line => line.Split(',')).ToDictionary(line => line[0], line => line[1]);

            return Morse;
        }
        public static void ConvertToMorse()
        {
            Dictionary <string, string> Morse = createDictionary();

            StandardMessages.getPhrase();
            string phrase = Console.ReadLine();
            phrase = phrase.ToUpper();
            string coded = "";

            for (int i =0; i<phrase.Length; i++)
            {
                if (phrase[i]==',')
                {
                    coded += "--..--";
                }
                else
                {
                    if (Morse.ContainsKey(phrase[i].ToString()))
                    {
                        coded += Morse[phrase[i].ToString()];
                    }
                    else
                    {
                        coded += phrase[i].ToString();
                    }
                }
            }
            Console.WriteLine(coded);
        }
    }
}
