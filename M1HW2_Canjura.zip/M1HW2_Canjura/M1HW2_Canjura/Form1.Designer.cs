﻿namespace M1HW2_Canjura
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.daysMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.Calculate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter the number of days to find out your pay.";
            // 
            // daysMaskedTextBox
            // 
            this.daysMaskedTextBox.Location = new System.Drawing.Point(163, 47);
            this.daysMaskedTextBox.Mask = "0000000";
            this.daysMaskedTextBox.Name = "daysMaskedTextBox";
            this.daysMaskedTextBox.Size = new System.Drawing.Size(75, 20);
            this.daysMaskedTextBox.TabIndex = 1;
            this.daysMaskedTextBox.ValidatingType = typeof(int);
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(62, 89);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(88, 23);
            this.Calculate.TabIndex = 2;
            this.Calculate.Text = "Calculate Pay";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Enter days worked:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(163, 88);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 124);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.daysMaskedTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Pennies for Pay";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox daysMaskedTextBox;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button exitButton;
    }
}

