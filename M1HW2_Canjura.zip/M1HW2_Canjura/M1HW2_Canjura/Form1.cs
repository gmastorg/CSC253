﻿/**
* 08/25/2018
* CSC 253
* Gabriela Canjura
* Calculates pay when user inputs days at rate of the penny amount per day she works 
* ex 3 days is 1+2+3 = 6 pennies
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            int days;
            decimal pay = 0;
            int penny = 0;
            decimal dollars;

            //parses input to int
            days = int.Parse(daysMaskedTextBox.Text);

            do
            {
                //calculates the pay
                pay = pay + penny;
                penny++;
            }
            while (penny <= days);

            //converts pennies to dollar fromat
            dollars = pay / 100;

            MessageBox.Show("Your payment is " +dollars.ToString("C")+'.');

            //clears the text box
            daysMaskedTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
