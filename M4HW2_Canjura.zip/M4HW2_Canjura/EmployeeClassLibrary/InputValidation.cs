﻿/**
* 10/24/2018
* CSC 253
* Gabriela Canjura
* validates input from user
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class InputValidation
    {

        public static int getMenuOption()
        {
            string decision;
            int choice;

            decision = Console.ReadLine();

            //checks if it is not a number
            while (char.IsDigit(decision, 0) == false)
                {
                    StandardMessages.InvalidInput();
                    decision = Console.ReadLine();
                }
            choice = int.Parse(decision);

            //checks if number is in menu
            while (choice < 1 || choice > 3)
            {
                StandardMessages.InvalidInput();
                decision = Console.ReadLine();
                
                while (char.IsDigit(decision, 0) == false)
                {
                    StandardMessages.InvalidInput();
                    decision = Console.ReadLine();
                }
                choice = int.Parse(decision);
            }

            return choice;
        }

public static string getText()
        {
            string word = "";

            word = Console.ReadLine();

            //checks if text is left empty
            while (word == null || word == "" || word==" " || word=="\n")
            {
                StandardMessages.InvalidInput();

                word = Console.ReadLine();
            }

            return word;
        }
        public static int getIntegers()
        {
            string numbers = "";
            int number;
            ConsoleKeyInfo key;
            do
            {
                key = Console.ReadKey(true);

                //only let's user type numbers, commas and backspace
                if ((key.Key >= ConsoleKey.D0 && key.Key <= ConsoleKey.D9) || (key.Key >= ConsoleKey.NumPad0 && key.Key <= ConsoleKey.NumPad9) ||
                    key.Key == ConsoleKey.Backspace)
                {
                    //let's user backspace and erases item from string
                    if (key.Key == ConsoleKey.Backspace)
                    {
                        if (numbers.Count() > 0)
                        {
                            numbers = numbers.Remove(numbers.Count() - 1);
                            Console.Write("\b \b");
                        }
                    }
                    else
                    {
                        numbers += key.KeyChar;
                        Console.Write(key.KeyChar);
                    }
                }
            }
            while (key.Key != ConsoleKey.Enter);

            number = int.Parse(numbers);

            return number;
        }


        public static decimal getDecimal()
        {
            string numbers = "";
            decimal number;
            bool dec = false;
            ConsoleKeyInfo key;
            do
            {
                key = Console.ReadKey(true);

                //only let's user type numbers, commas and backspace
                if ((key.Key >= ConsoleKey.D0 && key.Key <= ConsoleKey.D9) || (key.Key >= ConsoleKey.NumPad0 && key.Key <= ConsoleKey.NumPad9) ||
                    key.Key == ConsoleKey.Backspace|| key.Key == ConsoleKey.OemPeriod)
                {
                    //let's user backspace and erases item from string
                    if (key.Key == ConsoleKey.Backspace)
                    {
                        if (numbers.Count() > 0)
                        {
                            numbers = numbers.Remove(numbers.Count() - 1);
                            Console.Write("\b \b");
                        }
                    }
                    else
                    {
                        numbers += key.KeyChar;
                        Console.Write(key.KeyChar);

                        //only allows user to type in 2 numbers after a decimal point
                        if (numbers.Contains(".")&& (numbers.Count() > numbers.IndexOf(".")+2))
                        {
                            dec = true;
                        }
                    }
                }
            }
            while (key.Key != ConsoleKey.Enter&&(dec==false));

            number = decimal.Parse(numbers);

            return number;
        }

    }
}
