﻿/**
* 10/24/2018
* CSC 253
* Gabriela Canjura
* holds messages displayed to user
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class StandardMessages
    {
        public static void Menu()
        {
            Console.WriteLine("\n1. Add Employee Information");
            Console.WriteLine("2. View Employees");
            Console.WriteLine("3. Exit");
            Console.WriteLine("Enter your menu choice: ");
        }

        public static void InvalidInput()
        {
            Console.WriteLine("Invalid choice.\n");
            Console.WriteLine("Enter valid data: ");
        }


        public static void FirstName()
        {
            Console.WriteLine("Enter First Name: ");
        }

        public static void LastName()
        {
            Console.WriteLine("Enter Last Name: ");
        }

        public static void EmployeeNum()
        {
            Console.WriteLine("Enter Employee Number: ");
        }

        public static void Shift()
        {
            Console.WriteLine("\nEnter Employee Shift (1 = Morning, 2 = Evening): ");
        }

        public static void Pay()
        {
            Console.WriteLine("\nEnter Pay: ");
        }

        //holds output to messagebox
        public static string output(ShiftSupervisor selectedSupervisor)
        {
            string output = $"Shift Supervisor\nFirst Name: {selectedSupervisor.FirstName}" +
                $"\nLast Name: {selectedSupervisor.LastName}\nEmployee Number: {selectedSupervisor.Number}" +
                $"\nShift: (1 = Morning, 2 = Evening) {selectedSupervisor.Shift}\nAnnual Salary: " +
                $"{selectedSupervisor.AnnualSalary.ToString("c")}\nAnnual Bonus: {selectedSupervisor.AnnualBonus.ToString("c")}";

            return output;
        }
    }
}
