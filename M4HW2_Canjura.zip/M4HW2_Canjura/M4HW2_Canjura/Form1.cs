﻿/**
* 10/26/2018
* CSC 253
* Gabriela Canjura
* Adds shift supervisors and displays data in messagebox
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary;

namespace M4HW2_Canjura
{
    public partial class Form1 : Form
    {
        List<ShiftSupervisor> shiftSupervisors = new List<ShiftSupervisor>();
        public Form1()
        {
            InitializeComponent();      
        }

        // creates list of supervisor objects 
        private void addEmployeeButton_Click(object sender, EventArgs e)
        {
            //checks that box is not null and doesn't have a decimal point
            if (firstNameTextBox.Text != "" && lastNameTextBox.Text !="" && empNumMaskedTextBox.Text != "" 
                && shiftMaskedTextBox.Text != "" && salaryMaskedTextBox.Text != ""
                && bonusMaskedTextBox.Text != "")
            {
                string firstName = firstNameTextBox.Text;
                string lastname = lastNameTextBox.Text;
                int number = int.Parse(empNumMaskedTextBox.Text);
                int shift = int.Parse(shiftMaskedTextBox.Text);
                int annualSalary = int.Parse(salaryMaskedTextBox.Text);
                int annualBonus = int.Parse(bonusMaskedTextBox.Text);

                //creates shift supervisor object
                ShiftSupervisor shiftsupervisor = new ShiftSupervisor(firstName, lastname, number, shift, annualSalary, annualBonus);
                shiftSupervisors.Add(shiftsupervisor);

                //displays names in listbox
                displayListBox.Items.Add(firstName+" "+lastname);
                
                //method that clears the text boxes
                clear();
            }
            else
            {
                //displays if text box left empty
                MessageBox.Show("Please enter all the data requested.");
            }

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //closes form
            this.Close();
        }

        //clears textboxes
        public void clear()
        {
            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            empNumMaskedTextBox.Text = "";
            shiftMaskedTextBox.Text = "";
            salaryMaskedTextBox.Text = "";
            bonusMaskedTextBox.Text = "";
        }

        //calls appropriate object to display data in message box
        private void displayListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (displayListBox.SelectedIndex != -1)
            {
                ShiftSupervisor selectedSupervisor = shiftSupervisors[displayListBox.SelectedIndex];
                string output = StandardMessages.output(selectedSupervisor);
                MessageBox.Show(output);
            }
        }
    }
}

