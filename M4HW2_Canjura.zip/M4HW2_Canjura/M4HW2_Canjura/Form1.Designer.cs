﻿namespace M4HW2_Canjura
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.addEmployeeButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.empNumMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.shiftMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.salaryMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.bonusMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.displayListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(168, 31);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(145, 20);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name:";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(167, 60);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(145, 20);
            this.lastNameTextBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Employee Number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Shift (1=Morning, 2= Evening):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Annual Salary:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Annual Bonus:";
            // 
            // addEmployeeButton
            // 
            this.addEmployeeButton.Location = new System.Drawing.Point(54, 230);
            this.addEmployeeButton.Name = "addEmployeeButton";
            this.addEmployeeButton.Size = new System.Drawing.Size(75, 23);
            this.addEmployeeButton.TabIndex = 8;
            this.addEmployeeButton.Text = "Add ";
            this.addEmployeeButton.UseVisualStyleBackColor = true;
            this.addEmployeeButton.Click += new System.EventHandler(this.addEmployeeButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(179, 230);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 9;
            this.closeButton.Text = "Exit";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // empNumMaskedTextBox
            // 
            this.empNumMaskedTextBox.Location = new System.Drawing.Point(168, 88);
            this.empNumMaskedTextBox.Mask = "000000000";
            this.empNumMaskedTextBox.Name = "empNumMaskedTextBox";
            this.empNumMaskedTextBox.Size = new System.Drawing.Size(144, 20);
            this.empNumMaskedTextBox.TabIndex = 4;
            // 
            // shiftMaskedTextBox
            // 
            this.shiftMaskedTextBox.Location = new System.Drawing.Point(168, 114);
            this.shiftMaskedTextBox.Mask = "0";
            this.shiftMaskedTextBox.Name = "shiftMaskedTextBox";
            this.shiftMaskedTextBox.Size = new System.Drawing.Size(145, 20);
            this.shiftMaskedTextBox.TabIndex = 5;
            // 
            // salaryMaskedTextBox
            // 
            this.salaryMaskedTextBox.Location = new System.Drawing.Point(167, 140);
            this.salaryMaskedTextBox.Mask = "00000000";
            this.salaryMaskedTextBox.Name = "salaryMaskedTextBox";
            this.salaryMaskedTextBox.Size = new System.Drawing.Size(145, 20);
            this.salaryMaskedTextBox.TabIndex = 6;
            // 
            // bonusMaskedTextBox
            // 
            this.bonusMaskedTextBox.Location = new System.Drawing.Point(167, 164);
            this.bonusMaskedTextBox.Mask = "00000000";
            this.bonusMaskedTextBox.Name = "bonusMaskedTextBox";
            this.bonusMaskedTextBox.Size = new System.Drawing.Size(146, 20);
            this.bonusMaskedTextBox.TabIndex = 7;
            // 
            // displayListBox
            // 
            this.displayListBox.FormattingEnabled = true;
            this.displayListBox.Location = new System.Drawing.Point(343, 12);
            this.displayListBox.Name = "displayListBox";
            this.displayListBox.Size = new System.Drawing.Size(266, 238);
            this.displayListBox.TabIndex = 19;
            this.displayListBox.SelectedIndexChanged += new System.EventHandler(this.displayListBox_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 265);
            this.Controls.Add(this.displayListBox);
            this.Controls.Add(this.bonusMaskedTextBox);
            this.Controls.Add(this.salaryMaskedTextBox);
            this.Controls.Add(this.shiftMaskedTextBox);
            this.Controls.Add(this.empNumMaskedTextBox);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.addEmployeeButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.firstNameTextBox);
            this.Name = "Form1";
            this.Text = "Shift Supervisor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button addEmployeeButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.MaskedTextBox empNumMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox shiftMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox salaryMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox bonusMaskedTextBox;
        private System.Windows.Forms.ListBox displayListBox;
    }
}

