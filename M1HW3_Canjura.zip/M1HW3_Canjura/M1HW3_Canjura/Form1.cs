﻿/**
* 09/04/2018
* CSC 253
* Gabriela Canjura
* calculates kinetic energy of an object given the mass and velocity
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW3_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double mass;
            double velocity;

            //validates velocity input
            if (double.TryParse(velocityTextBox.Text, out velocity))
            {   //validates mass input
                if (double.TryParse(massTextBox.Text, out mass))
                {
                    // converts ponds to kilograms
                    if (poundsRadioButton.Checked)
                    {
                        
                        mass = mass * 0.45359237;
                        //calls the method
                        KineticEnergy(mass, velocity);
                    }
                    if (kilogramRadioButton.Checked)
                    {
                        mass = double.Parse(massTextBox.Text);
                        KineticEnergy(mass, velocity);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid mass.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid velocity.");
            }

            //clears text boxes
            massTextBox.Text = "";
            velocityTextBox.Text = "";
        }

       
            //method to calculate the kinetic energy
            private void KineticEnergy(double mass, double velocity)
        {
            double kineticEnergy;

            kineticEnergy = .5 * mass * (Math.Pow(velocity, 2));

            MessageBox.Show("The Kinetic Energy for an item with a mass of " + mass.ToString("n2") +
                " kilogram(s) and a velocity of " + velocity.ToString("n2") + " meter(s) per second is " 
                + kineticEnergy.ToString("n2") + " joule(s).");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
