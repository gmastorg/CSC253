﻿/**
* 09/29/2018
* CSC 253
* Gabriela Canjura
* simulates a tic tac toe game using 2D Array
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW4_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            //used to assign random coordinates to place x
            Random rand = new Random();

            const int ROWS = 3;
            const int COLS = 3;

            int[,] move = new int[ROWS, COLS];

            //clears array
            Array.Clear(move, 0, move.Length);

            //asssumes O goes first giving them 5 moves and X 4 moves
            // then takes advantage of fact the int array initializes elements to 0
            
            while (move[0, 0] + move[0, 1] + move[0, 2] + move[1, 0] + move[1,1]+
                move[1,2]+ move[2,0]+move[2,1]+move[2,2] != 4)
            //while statement ensures 4 moves are given to x in event that the random number
            //generator selects the same spot twice to assign x to 
            {
                int row = rand.Next(0,3);
                int col = rand.Next(0,3);
                
                if (move[row, col] == 0)
                {
                    move[row, col] = 1;
                }

            }

            string win = winner(move);

            if (win == "O" || win == "X")
            {
                outputLabel.Text = $"{win} is the winner.";
            }
            else
            {
                outputLabel.Text = win;
            }

            pictureBox1.Image = XOImageList.Images[move[0, 0]];
            pictureBox2.Image = XOImageList.Images[move[0, 1]];
            pictureBox3.Image = XOImageList.Images[move[0, 2]];
            pictureBox4.Image = XOImageList.Images[move[1, 0]];
            pictureBox5.Image = XOImageList.Images[move[1, 1]];
            pictureBox6.Image = XOImageList.Images[move[1, 2]];
            pictureBox7.Image = XOImageList.Images[move[2, 0]];
            pictureBox8.Image = XOImageList.Images[move[2, 1]];
            pictureBox9.Image = XOImageList.Images[move[2, 2]];
 
        }

        public string winner(int[,] move)
            //determines winner (could not figure out a way to have it  exit after one wins) 
            //ie take turns) if both x and o get three in a row will declare x winner bc its
            //if statement is first.
        {
            string win;

            if (move[0, 0] + move[0, 1] + move[0, 2] == 3 ||
                move[0, 0] + move[1, 0] + move[2, 0] == 3 ||
                move[0, 0] + move[1, 1] + move[2, 2] == 3 ||
                move[0, 2] + move[1, 1] + move[2, 0] == 3 ||
                move[1, 0] + move[1, 1] + move[1, 2] == 3 ||
                move[2, 0] + move[2, 1] + move[2, 2] == 3 ||
                move[0, 1] + move[1, 1] + move[2, 1] == 3 ||
                move[0, 2] + move[1, 2] + move[2, 2] == 3)
            {
                return win = "X";
            }
            else if(move[0, 0] + move[0, 1] + move[0, 2] == 0 ||
                    move[0, 0] + move[1, 0] + move[2, 0] == 0 ||
                    move[0, 0] + move[1, 1] + move[2, 2] == 0 ||
                    move[0, 2] + move[1, 1] + move[2, 0] == 0 ||
                    move[1, 0] + move[1, 1] + move[1, 2] == 0 ||
                    move[2, 0] + move[2, 1] + move[2, 2] == 0 ||
                    move[0, 1] + move[1, 1] + move[2, 1] == 0 ||
                    move[0, 2] + move[1, 2] + move[2, 2] == 0)
                 {
                    return win = "O";
                 }                
           else
           {
                return win = "Tied";
           }       
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = "";

            pictureBox1.Image = null;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
            pictureBox4.Image = null;
            pictureBox5.Image = null;
            pictureBox6.Image = null;
            pictureBox7.Image = null;
            pictureBox8.Image = null;
            pictureBox9.Image = null;
        }
    }
}
