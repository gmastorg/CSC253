﻿namespace M5HW1_Canjura
{


    partial class PersonnelDataSet
    {
    }
}

namespace M5HW1_Canjura.PersonnelDataSetTableAdapters {
    
    
    public partial class PersonnelTableAdapter {
    }
}
