﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLibrary
{
    public class RetailItem
    {
        
        public string Description { get; set; }
        public int UnitsOnHand { get; set; }
        public decimal Price { get; set; }

        // Constructor
        public RetailItem(string description, int unitsOnHand, decimal price)
        {
            Description = description;

            UnitsOnHand = unitsOnHand;

            Price = price;
        }
      

    }
}
