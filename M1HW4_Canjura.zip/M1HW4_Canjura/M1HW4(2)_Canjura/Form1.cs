﻿/**
* 09/06/2018
* CSC 253
* Gabriela Canjura
* creates a class that holds inventory of retail products then places them in an array which is 
* then displayed
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailItemClassLibrary;

namespace M1HW4_2__Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Add("\t\t" + "Description" + "\t" +
                "Units on Hand" + "\t" + "Price");
            outputListBox.Items.Add("\n------------------------------------------------------"+
                "-------------------------------------------------------------------------");

            RetailItem[] inventory = {
                          new RetailItem ("Jacket", 12, 59.95M),
                          new RetailItem ("Jeans", 40, 34.95M),
                          new RetailItem ("Shirt", 20, 24.95M)
                         };

            int x = 1;
            foreach (RetailItem item in inventory)
            {
                outputListBox.Items.Add("Item"+ x +"\t\t"+item.Description +"\t\t"+ item.UnitsOnHand +
                    "\t\t"+item.Price.ToString("C"));
                x++;
            }
            
        }
    }
}
