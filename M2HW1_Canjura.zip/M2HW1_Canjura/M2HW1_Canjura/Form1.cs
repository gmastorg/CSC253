﻿/**
* 09/13/2018
* CSC 253
* Gabriela Canjura
* creates an array from a file and displays infrmation in listbox
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M2HW1_Canjura

{ 
    public partial class Form1 : Form
    {
        // declared here so that all buttons have access to this
        decimal[] numArray;

        public Form1()
        {
            InitializeComponent();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            // checks to see if this was already generated with total button
            if (numArray == null)
            {
                //calls method to read file and create array
                numArray = getData();
            }
            //calls output method
            output(numArray);
        }


        public decimal[] getData()
        {
            StreamReader inputFile;

            //creates a list to hold values so that you do not have to declare the size of the
            //array prior to creation
            List<decimal> numbers = new List<decimal>();

            //used to hold items parsed from file
            decimal number;

            //makes sure item is selected in dialod box
           if (openFile.ShowDialog() == DialogResult.OK)
            {
                inputFile = File.OpenText(openFile.FileName);

                while (!inputFile.EndOfStream)
                {
                    if(decimal.TryParse(inputFile.ReadLine(), out number))
                    {
                        //adds numbers to list
                        numbers.Add(number);
                    }
                    else
                    {
                        MessageBox.Show("Incorrect data type.");
                    }
                }
            }
           else
            {
                MessageBox.Show("Operation Cancelled.");
            }

            // converts list to array
            numArray = numbers.ToArray();
            return numArray;
        }

        public void output(decimal[] numArray)
        {
            // displays data in listbox
            foreach (decimal val in numArray)
            {
                outputListBox.Items.Add(val.ToString("c"));
            }
        }

        public void getTotal(decimal[] numArray)
        {
            decimal total = 0M;

            //checks to see if array was already created in view button
            if (numArray == null)
            {
                numArray = getData();
            }

            // adds the items in array
            foreach (decimal val in numArray)
            {
                total += val;
            }

            //displays total
            totalLabel.Text = total.ToString("c");
        }


        private void exittButton_Click(object sender, EventArgs e)
        {
            //exits
            this.Close();
        }

        private void totalButton_Click(object sender, EventArgs e)
        {
            //calls method
            getTotal(numArray);
        }
    }
}
