﻿/**
* 09/20/2018
* CSC 253
* Gabriela Canjura
* reads two files and places data into arrays then searches files for specific data 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M2HW3_Canjura
{
    class Program
    {
        public static void Main(string[] args)
        {
            string keepGoing;

            // loop to keep console open
            do
            {
                //methods to collect array data from files

                string [] girlArray = readGirlFile(); 

                string[] boyArray = readBoyFile();

                //methd to check arrays for specific names
                checkNames(girlArray, boyArray);

                Console.WriteLine("Would you like to try again (Y/N)?");
                keepGoing = Console.ReadLine();
                keepGoing = keepGoing.ToLower();
            }
            while (keepGoing == "y");
        }

        public static string [] readGirlFile()
        {
            // gets input from file
            StreamReader inputFile;
            string line;

            //places data in list so that you do not have to know array length
            List<string> girlName = new List<string>();

            try
            {
                inputFile = File.OpenText(@"E:\2018 FA CSC253\Programs\M2HW3_Canjura\GirlNames.txt");

                //loop to read file and assign text to list 
                while (!inputFile.EndOfStream)
                {
                    line = inputFile.ReadLine();
                    
                    //makes text lower case for easier search
                    line = line.ToLower();
                    girlName.Add(line);
                }
            }
            catch
            {
                // if file not at specified path will throw this error
                Console.WriteLine("File not Found");
            }

            // makes array from the list
            string[] girlArray = girlName.ToArray();

            return girlArray;
        }

        public static string[] readBoyFile()
        {
            StreamReader inputFile;
            string line;

            List<string> boyName = new List<string>();

            try
            { 
                inputFile = File.OpenText(@"E:\2018 FA CSC253\Programs\M2HW3_Canjura\BoyNames.txt");

                while (!inputFile.EndOfStream)
                {
                    line = inputFile.ReadLine();
                    line = line.ToLower();
                    boyName.Add(line);
                }
            }
            catch
            {
                Console.WriteLine("File not Found");
            }
            string[] boyArray = boyName.ToArray();

            return boyArray;
        }

        public static void checkNames(string[] girlArray, string[] boyArray)
        {
            int index = 0;
            // sets answer to a default of is not
            string answer = "is not";

            //gets name to check from user
            Console.WriteLine("Enter the name you would like to check: ");
            string name = Console.ReadLine();
            // makes name lowercase for easier search
            name = name.ToLower();

            //checks both arrays at same time
            while(index < girlArray.Length || index < boyArray.Length)
            {
                //if name is found answer changed to is
                if (name == girlArray[index] || name == boyArray[index]) 
                {
                    answer = "is";
                }
              
                index += 1;
            }
            
            //capitalizes first letter
            string firstLetterName = name.First().ToString().ToUpper();
            name = firstLetterName + name.Substring(1);

            //displays answer
            Console.WriteLine($"{name} {answer} among the most popular names " +
                $"from 2000 - 2009 for boys and girls.");
        }
    }

   
}
