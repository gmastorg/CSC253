﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalInfoClassLibrary
{
    public class PersonEntry
    {
        private string Name { get; set; }
        private string Email { get; set; }
        private string Phone { get; set; }
        private int Age { get; set; }

        public void getData(string name, string email, string phone, int age)
        {

        }
    

    }
    
}
