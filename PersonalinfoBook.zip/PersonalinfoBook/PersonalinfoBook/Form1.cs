﻿/* Gabriela Canjura
 * CSC 253
 * 09/11/2018
 * takes information from a file and displays it in a list box using a class
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonalInfoClassLibrary;
using System.IO;

namespace PersonalinfoBook
{
    public partial class Form1 : Form
    {
        // creates an object
        PersonEntry person = new PersonEntry();

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {

            // creates variable to read file
            StreamReader inputFile;

            //assigns file to variable
            inputFile = File.OpenText("People.txt");

            //creates a loop to read the lines of the file 
            while (!inputFile.EndOfStream)
            {
                // variable to hold contents of the line in file
                PersonEntry person = new PersonEntry
                                        {
                                        inputFile.ReadLine();
                                        inputFile.ReadLine();
                                        inputFile.ReadLine();
                                        int.Parse(inputFile.ReadLine());
                                        }

                outputListBox.Items.Add(person.name);
            }

        private void outputListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

