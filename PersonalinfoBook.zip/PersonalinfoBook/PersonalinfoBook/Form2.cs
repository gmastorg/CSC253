﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonalInfoClassLibrary;


namespace PersonalinfoBook
{
    public partial class Form2 : Form
    {
        public Form2(PersonEntry person)
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //displays data in listbox
            outputListBox.Items.Add("Name: " + person.name);
            outputListBox.Items.Add("E-Mail: " + person.email);
            outputListBox.Items.Add("Phone: " + person.phone);
            outputListBox.Items.Add("Age: " + person.age);

            //determines age category for each person
            if (person.age <=12)
            {
                outputListBox.Items.Add("This person is a kid. In " + (13 - person.age) + " year(s) they will be a teen.");
            }
            else if(person.age >= 13 < 18)
            {
                outputListBox.Items.Add("This person is a teen. In " + (18 - person.age) + " year(s) they will be an adult.");
            }
            else if (person.age >= 18 < 65)
            {
                outputListBox.Items.Add("This person is an adult. In " + (65 - person.age) + " year(s) they will be a senior.");
            }
            else
            {
                outputListBox.Items.Add("This person is a senior");
            }

        }
    }
}
.