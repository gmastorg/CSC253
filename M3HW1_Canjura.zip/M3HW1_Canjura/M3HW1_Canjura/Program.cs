﻿/**
* 10/04/2018
* CSC 253
* Gabriela Canjura
* takes a string with a sentence converts it to an array of words and counts the words
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW1_Canjura
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice = 1;
            string decision = "";

            // exits if menu choice is exit
            while (choice != 2)
            {
                Console.WriteLine("1. Count words in phrase");
                Console.WriteLine("2. Exit");
                Console.WriteLine("Enter your menu choice: ");
                decision = Console.ReadLine();

                //checks for a character
                while (char.IsDigit(decision, 0) == false)
                {
                    Console.WriteLine("Invalid choice.");
                    Console.WriteLine("Enter your menu choice: ");
                    decision = Console.ReadLine();
                }
                choice = int.Parse(decision);

                //checks that entry is in menu
                while (choice < 1 || choice > 2)
                {
                    Console.WriteLine("Invalid choice.");
                    Console.WriteLine("Enter your menu choice: ");
                    decision = Console.ReadLine();
                    choice = int.Parse(decision);
                }

                //runs function to count words if 1 is selected from menu
                if (choice == 1)
                {
                    Console.WriteLine("\nEnter the phrase you would like to check:");
                    string sentence = Console.ReadLine();
                    string[] token = countWords(sentence);
                    //displays count of words
                    Console.WriteLine($"\nThere are {token.Length} words in your phrase.\n");
                }
            }
        }

        public static string [] countWords(string sentence)
        {
            //creates array of words
            string[] token = sentence.Split(null);

            //returns array
            return token;
        }
    }

}
