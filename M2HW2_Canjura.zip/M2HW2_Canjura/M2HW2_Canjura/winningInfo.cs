﻿/**
* 09/13/2018
* CSC 253
* Gabriela Canjura
* creates a list of winning teams gets rid of duplicates then shows years that the specific team 
* won the world series and how many times total they won
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Canjura
{
    public partial class winningInfo : Form
    {
        public winningInfo(string name, int times, List<int> winningYears)
        {
            InitializeComponent();

            //Displays how many times the team selected won
            outputLabel.Text = $"{name} won the World Series {times} in the following years:";

            //displays items in winning years in a listbox
            foreach (int val in winningYears)
            {
                yearsListBox.Items.Add(val);
            }
        }

    }
}
