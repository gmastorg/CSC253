﻿namespace M2HW2_Canjura
{
    partial class winningInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.outputLabel = new System.Windows.Forms.Label();
            this.yearsListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // outputLabel
            // 
            this.outputLabel.Location = new System.Drawing.Point(44, 37);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(289, 33);
            this.outputLabel.TabIndex = 0;
            // 
            // yearsListBox
            // 
            this.yearsListBox.FormattingEnabled = true;
            this.yearsListBox.Location = new System.Drawing.Point(44, 80);
            this.yearsListBox.Name = "yearsListBox";
            this.yearsListBox.Size = new System.Drawing.Size(289, 108);
            this.yearsListBox.TabIndex = 1;
            // 
            // winningInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 220);
            this.Controls.Add(this.yearsListBox);
            this.Controls.Add(this.outputLabel);
            this.Name = "winningInfo";
            this.Text = "World Series Winners";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.ListBox yearsListBox;
    }
}