﻿/**
* 09/13/2018
* CSC 253
* Gabriela Canjura
* creates a list of winning teams gets rid of duplicates then shows years that the specific team 
* won the world series and how many times total they won
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M2HW2_Canjura
{
    public partial class Form1 : Form
    {
        // created here so rest of methods can see these
        List<string> distinctTeams = new List<string>();
        List<string> teams = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                StreamReader inputFile;

                string line;
                
                //opens file from this specific location              
                inputFile = File.OpenText(@"E:\2018 FA CSC253\WorldSeriesWinners.txt");

                //reads through file and creates list with text in each line
                while (!inputFile.EndOfStream)
                {
                    line = inputFile.ReadLine();

                    teams.Add(line);
                }

                //removes dupllicates
                distinctTeams = teams.Distinct().ToList();


                //sorts items alphabetically
                distinctTeams.Sort();

                //adds the items in list to list box
                foreach (string item in distinctTeams)
                {
                    teamsListBox.Items.Add(item);
                }
            }
            
            //sends error message if file not found
            catch
            {
                MessageBox.Show("Teams not found.");
            }
        }

        private void teamsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //assigns index of item selected to index variable
            int index = teamsListBox.SelectedIndex;

            //assigns element in list at specific index to name variable
            string name = distinctTeams.ElementAt(index);

            //calls method timesWon
            timesWon(name);
        }

        public void timesWon(string name)
        {
            int times = 0;
            int year = 1902;
            List<int> years = new List<int>();
            List<int> winningYears = new List<int>();

            //runs through list
            for (int i=0; i < teams.Count; i++)
            {
                // creates a list with year numbers corresponding to the number of elements in 
                // teams list while skipping 1904 and 1994
                if (year == 1903 || year == 1993)
                {
                    year = year + 2;
                    years.Add(year);
                }
                else
                {
                    year = year + 1;
                    years.Add(year);
                }

                // obtains specific info for team selected

                //checks if variable name is same as string in teams at this index
                if (name == teams.ElementAt(i))
                {
                    //keeps tally of times won
                    times = times + 1;

                    //adds year at the index to the list winning years
                    winningYears.Add(years.ElementAt(i));
                }
            }

            // creates an object for the second form and sends name, times, and winningYears 
            // list to second form
            winningInfo winner = new winningInfo(name, times, winningYears);

            //shows second form
            winner.Show();
        }
    }
}
