﻿/**
* 11/04/2018
* CSC 253
* Gabriela Canjura
* obtains team lead information and then displays it
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClassLibrary;

namespace M4HW3_Canjura
{
    class Program
    {
        static void Main(string[] args)
        {
            List<TeamLead> employees = new List<TeamLead>();

            int choice = 1;


            //exits if it is 3
            while (choice != 3)
            {
                StandardMessages.Menu();
                choice = InputValidation.getMenuOption();

                //calls method to add the numbers
                if (choice == 1)
                {
                    employees = getEmployeeData(employees);
                }

                if (choice == 2)
                {
                    printEmployees(employees);
                }
            }
        }

        public static List<TeamLead> getEmployeeData(List<TeamLead> employees)
        {//receives input from user and validates data

            StandardMessages.FirstName();
            string firstName = InputValidation.getText();

            StandardMessages.LastName();
            string lastName = InputValidation.getText();

            StandardMessages.EmployeeNum();
            int number = InputValidation.getIntegers();

            StandardMessages.Shift();
            int shift = InputValidation.getIntegers();

            StandardMessages.Pay();
            decimal pay = InputValidation.getDecimal();

            StandardMessages.trainingHours();
            decimal hours = InputValidation.getDecimal();

            StandardMessages.monthlyBonus();
            decimal bonus = InputValidation.getDecimal();

            TeamLead employee = new TeamLead(firstName, lastName, number, shift, pay, hours, bonus);
            employees.Add(employee);

            return employees;
        }

        public static void printEmployees(List<TeamLead> employees)
        {
            foreach( TeamLead item in employees)
            {
                Console.WriteLine(item);
            }
        }
    }
}
