﻿/**
* 10/24/2018
* CSC 253
* Gabriela Canjura
* used for production worker objects
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    //inherits from employee class
    public class ProductionWorker:Employee
    {
        public int Shift { get; set; }
        public decimal Pay { get; set; }


        //constructor
        public ProductionWorker (string firstname, string lastname, int number, int shift, decimal pay): base( firstname, lastname, number)
        {
            FirstName = firstname;
            LastName = lastname;
            Number = number;
            Shift = shift;
            Pay = pay;
        }

    }
}
