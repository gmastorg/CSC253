﻿/**
* 10/26/2018
* CSC 253
* Gabriela Canjura
* shift supervisor class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class ShiftSupervisor:Employee
    {
        public int Shift { get; set; }
        public int AnnualSalary { get; set; }
        public int AnnualBonus { get; set; }


        public ShiftSupervisor(string firstname, string lastname, int number, int shift,  int annualsalary, int annualbonus) : base(firstname, lastname, number)
        {
            FirstName = firstname;
            LastName = lastname;
            Number = number;
            Shift = shift;
            AnnualSalary = annualsalary;
            AnnualBonus = annualbonus;
        }

    }
}
