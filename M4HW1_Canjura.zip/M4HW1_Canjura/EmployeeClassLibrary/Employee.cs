﻿/**
* 10/24/2018
* CSC 253
* Gabriela Canjura
* used for employee objects also the parent class to production worker class
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Number { get; set;}

        //constructor
        public Employee(string firstname, string lastname, int number)
        {
            FirstName = firstname;
            LastName = lastname;
            Number = number;
        }
    }
}
