﻿/**
* 08/23/2018
* CSC 253
* Gabriela Canjura
* this program receives input from a user about books ordered and gives them their reward
* point balance based on preset point amounts
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW1_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //variables for books ordered and reward points
            int books = 0;
            int points = 0;

            //assigns text from text box to variable books
            books = int.Parse(booksMaskedTextBox.Text);
            
            //determines reward points for the books ordered
            switch(books)
            {
                case 0:
                    points = 0;
                    break;
                case 1:
                    points = 5;
                    break;
                case 2:
                    points = 15;
                    break;
                case 3:
                    points = 30;
                    break;
                default:
                    points = 60;
                    break;
            }

            //displays books purchased and points earned
            MessageBox.Show("You bought " + books + " books and earned " + points + " reward points.");

            //clears textbox after message box is closed
            booksMaskedTextBox.Text = "";
        }
    }
}
