﻿/**
* 10/09/2018
* CSC 253
* Gabriela Canjura
* receives a string from user seperates values by commas and then adds values
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW2_Canjura
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice = 1;
            string decision;

            //exits if it is 2
            while (choice != 2)
            {
                Console.WriteLine("1. Add numbers together");
                Console.WriteLine("2. Exit");
                Console.WriteLine("Enter your menu choice: ");
                decision = Console.ReadLine();

                //checks if it is not a number
                while (char.IsDigit(decision, 0) == false)
                {
                    Console.WriteLine("Invalid choice.");
                    Console.WriteLine("Enter your menu choice: ");
                    decision = Console.ReadLine();
                }
                choice = int.Parse(decision);

                //checks if number is in menu
                while (choice < 1 || choice > 2)
                {
                    Console.WriteLine("Invalid choice.");
                    Console.WriteLine("Enter your menu choice: ");
                    decision = Console.ReadLine();
                    choice = int.Parse(decision);
                }

                //calls method to add the numbers
                if (choice == 1)
                {
                    string numbers = "";
                    Console.WriteLine("\nEnter the numbers you would like to add: ");
                    ConsoleKeyInfo key;

                    do
                    {
                        key = Console.ReadKey(true);
                        
                        //only let's user type numbers, commas and backspace
                        if ((key.Key >= ConsoleKey.D0 && key.Key <= ConsoleKey.D9) || (key.Key >= ConsoleKey.NumPad0 && key.Key <= ConsoleKey.NumPad9) || 
                            key.Key == ConsoleKey.OemComma|| key.Key == ConsoleKey.Backspace)
                        {
                            //let's user backspace and erases item from string
                            if (key.Key == ConsoleKey.Backspace)
                            {
                                numbers = numbers.Remove(numbers.Count() - 1);
                                Console.Write("\b \b");
                            }
                            else
                            {
                                numbers += key.KeyChar;
                                Console.Write(key.KeyChar);
                            }
                        }
                    }
                    while (key.Key != ConsoleKey.Enter);

                    //removes trailing comma
                    numbers = numbers.TrimEnd(',');

                    addNumbers(numbers);
                }
            }
        }

        public static void addNumbers(string numbers)
        {
            // splits numbers string at comma and creates array of each number
            string[] token = numbers.Split(',');

            int total = 0;

            //verifies if array is null or not
            if (token == null)
            {
                Console.WriteLine($"You didn't enter any data.");
            }
            else
            {
               foreach (string val in token)
                { 
                    //parses string items in token to integers and adds them
                    total += int.Parse(val);
                }

                Console.WriteLine($"\nThe total of your numbers is {total}\n");
            }        
        }
    }
}

