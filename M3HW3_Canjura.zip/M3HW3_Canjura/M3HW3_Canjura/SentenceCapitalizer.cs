﻿/**
* 10/16/2018
* CSC 253
* Gabriela Canjura
* capitalizes the first word in each sentence.
* class that holds method to capitalize the first letter of each sentence
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW3_Canjura
{
    public class SentenceCapitalizer
    {
        public static void captalizeSentence()
        {
            StandardMessages.getSentence();
            string sentences = Console.ReadLine();
            
            //converts string to array
            char[] letters = sentences.ToCharArray();

            //checks string letter by letter
            for (int i = 0; i <sentences.Length; i++)
            {
                //capitalizes first letter
                letters[0] = char.ToUpper(letters[0]);
                //makes sure not at end of sentence
                if (!(i + 2 >= sentences.Length))
                {
                    //checks for punctuation
                    if (letters[i] == '.' || letters[i] == '?' || letters[i] == '!')
                    {
                        //checks for space after punctuation
                        if (letters[i + 1] == ' ')
                        {
                            letters[i + 2] = char.ToUpper(letters[i + 2]);
                        }
                        else
                        {
                            letters[i + 1] = char.ToUpper(letters[i + 1]);
                        }
                    }
                }
            }
            //string that holds corrected sentence from array
            string correctedSentence = new string (letters);
            Console.Write(correctedSentence);
        }
    }
}
