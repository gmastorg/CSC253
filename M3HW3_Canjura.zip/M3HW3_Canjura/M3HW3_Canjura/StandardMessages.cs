﻿/**
* 10/16/2018
* CSC 253
* Gabriela Canjura
* capitalizes the first word in each sentence.
* class that holds the output messages to the user
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW3_Canjura
{
    public class StandardMessages
    {
        public static void menu()
        {
            Console.WriteLine("1. Capitalize Sentence(s)");
            Console.WriteLine("2. Exit");
            Console.WriteLine("Enter choice: ");
        }

        public static void invalidInput()
        {
            Console.WriteLine("Invalid choice.");
            Console.WriteLine("Enter your menu choice: ");
        }

        public static void getSentence()
        {
            Console.WriteLine("Enter the sentence or sentences you would like to have " +
                "capitalized.");
        }
    }
}
