﻿/**
* 10/16/2018
* CSC 253
* Gabriela Canjura
* capitalizes the first word in each sentence.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW3_Canjura
{
    class Program
    {
        static void Main(string[] args)
        {
            int decision = 0;

            // keeps program running until user selects to exit
            while (decision != 2) 
            {
                //gets menu display from standard messages class
                StandardMessages.menu();
                String choice = Console.ReadLine();

                //validates input
                while (choice == "" || char.IsDigit(choice, 0) == false)
                {
                    //gives message that input was invalid
                    StandardMessages.invalidInput();
                    choice = Console.ReadLine();
                }
                decision = int.Parse(choice);

                //checks if number is in menu
                while (decision < 1 || decision > 2)
                {
                    StandardMessages.invalidInput();
                    choice = Console.ReadLine();
                    decision = int.Parse(choice);
                }

                if (decision == 1)
                {
                    //calls method from sentence capitalizer class
                    SentenceCapitalizer.captalizeSentence();
                    Console.WriteLine("\n");
                }
            }

        }
    }
}
